# Enable 'Change password' page
SECURITY_CHANGEABLE = True
