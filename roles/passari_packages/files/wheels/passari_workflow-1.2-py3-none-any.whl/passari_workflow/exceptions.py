class WorkflowJobRunningError(ValueError):
    """
    Operation was prevented by a job running in the job queue
    """
