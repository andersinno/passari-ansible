ZETCOM_NS = "http://www.zetcom.com/ria/ws/module"
ZETCOM_SESSION_NS = "http://www.zetcom.com/ria/ws/session"
ZETCOM_SEARCH_NS = "http://www.zetcom.com/ria/ws/module/search"
